#ifndef _X11_DISPLAY_H
#define _X11_DISPLAY_H

#include "Color.h"
#include <X11/Xlib.h>

// O n�mero de bits por pixel depende da configura��o do servidor X.
// A defini��o abaixo deve ser ajustada para que as cores apare�am corretamente.
#define VINTE_E_QUATRO
#ifdef VINTE_E_QUATRO
#define B_R 8
#define B_G 8
#define B_B 8
#else
#define B_R 5
#define B_G 6
#define B_B 5
#endif

/**
 Classe que representa uma tela em XWindows.
 */
class X11Display {

   private:
   
      Display *display;
      unsigned int screen;
      unsigned int _width;
      unsigned int _height;
      unsigned long _colors;
      Window window;
      GC gc;
      
   private:
   
      // Inicializa display, estabelecendo conex�o com servidor X.
      void createDisplay();
      
      // Calcula o n�mero m�ximo de cores que podem ser mostradas na tela.
      void initColors();
      
      // Inicializa janela, definindo seus atributos.
      void initWindow(int width, int height, char *name);
      
      // Inicializa o contexto gr�fico.
      void initGC();
      
      // Mostra janela.
      void displayWindow();
         
   public:

      void open(unsigned int width, unsigned int height, char *nome);
      
      void close();
      
      // Mostra na tela o ponto de coordenadas (x,y), pintando-o com color.
      void drawPoint(int x, int y, unsigned long color);

      // Mostra na tela o ponto de coordenadas (x,y), pintando-o com color (RGB).
      void drawPoint(int x, int y, Color color);
            
      // N�mero m�ximo de cores na tela.
      unsigned long colors();
      
      // Largura da tela.
      unsigned int width();
      
      // Altura da tela.
      unsigned int height();
      
      // Atualiza tela.
      void flush();
      
      // Calcula cor a partir de componentes vermelho, verde e azul
      // (r, g e b devem estar entre 0 e 1).
      unsigned long color(float r, float g, float b);
      
   
};

#endif   // _X11_DISPLAY_H
